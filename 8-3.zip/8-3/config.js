const nameGirl = '1 Cái Bits Thật Chill';
const giftUrl = 'https://www.instagram.com/aline.thaz?igsh=ejdqYnkwM2Y2NzY4';
const eventName = 'Yeah Nay Là 8-3 Rồi';
const titleCard = 'Hép Pi Hu Mần Đây';
const contentCard = 'Chúc Bạn Gì Nhỉ, À Đúng Rồi. Chúc Bạn Là Days Càng Xẹp Đinh Và Luôn Vẻ Vui Mỗi Days, Cười Tươi Như 🌼 Mà Không Bao Giờ 🥀';


const giftImage = 'hot-boy.jpg';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
